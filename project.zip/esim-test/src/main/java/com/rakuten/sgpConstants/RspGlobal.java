package com.rakuten.sgpConstants;

public class RspGlobal {
	
	
	public RspGlobal() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String euiccPkCert = "";
	public String euiccPk     = "";
	
	public String eumPkCert	 = "";
	public String eumPk     = "";
	
	public String getEuiccPkCert() {
		return euiccPkCert;
	}
	public void setEuiccPkCert(String euiccPkCERT) {
		euiccPkCert = euiccPkCERT;
	}
	public String getEuiccPk() {
		return euiccPk;
	}
	public void setEuiccPk(String euiccPK) {
		euiccPk = euiccPK;
	}
	public String getEumPkCert() {
		return eumPkCert;
	}
	public void setEumPkCert(String eumPkCert) {
		this.eumPkCert = eumPkCert;
	}
	public String getEumPk() {
		return eumPk;
	}
	public void setEumPk(String eumPk) {
		this.eumPk = eumPk;
	}
	
}
